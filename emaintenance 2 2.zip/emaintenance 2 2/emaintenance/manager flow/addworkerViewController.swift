//
//  addworkerViewController.swift
//  emaintenance
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class addworkerViewController: baseViewController {
    
    
    @IBOutlet weak var titleLabelOutlet: UILabel!
    @IBOutlet weak var nameTextfield: UITextField!
    @IBOutlet weak var mobileTextfield: UITextField!
    @IBOutlet weak var roleTextfield: UITextField!
    
    var titleName = ""
    
    var addWorker : addWorkerModel!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.titleLabelOutlet.text = titleName
        
    }
    @IBAction func addButton(_ sender: UIButton) {
        
        if titleLabelOutlet.text == "Add SuperViser" {
            postAPI()
        }else if titleLabelOutlet.text == "Add Worker"{
            
        }
       
    }

}
    extension addworkerViewController{
        
        
        
        func postAPI(){
            
            let formData = ["name":"\(nameTextfield.text ?? "Error")",
                       "mobnum":"\(mobileTextfield.text ?? "Error")",
                       "role":"\(roleTextfield.text ?? "Error")"]
            
            let apiURL = APIList().urlString(url:.add)
            print(apiURL)
               APIHandler().postAPIValues(type: addWorkerModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
                   switch result {
                   case .success(let data):
                       self.addWorker = data
                     print(data)
                       case .failure(let error):
                       
                       print(error)
                       let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                       alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                           print("JSON Error")
                       })
                          
                       self.present(alert, animated: true, completion: nil)
                       }
                   }
               }
        }



