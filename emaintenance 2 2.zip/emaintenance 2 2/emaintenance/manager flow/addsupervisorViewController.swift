//
//  addsupervisorViewController.swift
//  emaintenance
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class addsupervisorViewController: baseViewController {
    

    @IBOutlet weak var titleLabelOutlet: UILabel!
    @IBOutlet weak var nameTextfield: UITextField!
    @IBOutlet weak var mobileTextfield: UITextField!
    @IBOutlet weak var roleTextfield: UITextField!
    
    var titleName = ""
    
    var addSupervisor : addModel!
    
    var addWorker : addWorkerModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.titleLabelOutlet.text = titleName
    }
    
    @IBAction func addButton(_ sender: UIButton) {
        
        if nameTextfield.text?.isEmpty == true{
            showToast("Enter the name")
        }else if mobileTextfield.text?.isEmpty == true{
            showToast("Enter the mobile")
        }else if roleTextfield.text?.isEmpty == true{
            showToast("Enter the role")
        }else{
            postAPI()
        }
     }
    
    @IBAction func backButtonAction(_ sender: UIButton) {
        
      self.navigationController?.popViewController(animated: true)
     }
    
    @IBAction func menuButtonAction(_ sender: UIButton) {
        
        self.present(self.menu!, animated: true, completion: nil)
     }

}
extension addsupervisorViewController{
 func postAPI(){
     self.startIndicator()
     if titleLabelOutlet.text == "Add Supervisor" {
         let formData = ["name":"\(nameTextfield.text ?? "Error")",
                    "mobnum":"\(mobileTextfield.text ?? "Error")",
                    "role":"\(roleTextfield.text ?? "Error")"]
         let apiURL = APIList().urlString(url:.add)
         print(apiURL)
            APIHandler().postAPIValues(type: addModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
                switch result {
                case .success(let data):
                    
                    DispatchQueue.main.async {
                        self.stopIndicator()
                        self.addSupervisor = data
                        self.showAlert(title: "Success", message: data.message, okActionHandler: {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "equipmentViewController") as! equipmentViewController
                            self.navigationController?.pushViewController(vc, animated: true)
                        })
                    }
                  print(data)
                    case .failure(let error):
                    DispatchQueue.main.async {
                        self.stopIndicator()
                    
                    print(error)
                    let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                        print("JSON Error")
                    })
                    self.present(alert, animated: true, completion: nil)
                    }
                }
                }
     }else if titleLabelOutlet.text == "Add Worker" {
         
         let formData = ["name":"\(nameTextfield.text ?? "Error")",
                    "mobnum":"\(mobileTextfield.text ?? "Error")",
                    "role":"\(roleTextfield.text ?? "Error")"]
         let apiURL = APIList().urlString(url:.add)
         print(apiURL)
            APIHandler().postAPIValues(type: addWorkerModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async {
                        self.stopIndicator()
                        self.addWorker = data
                        self.showAlert(title: "Success", message: data.message, okActionHandler: {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "equipmentViewController") as! equipmentViewController
                            self.navigationController?.pushViewController(vc, animated: true)
                        })
                    }
                   
                  print(data)
                    case .failure(let error):
                    DispatchQueue.main.async {
                        self.stopIndicator()
                    print(error)
                    let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                        print("JSON Error")
                    })
                    self.present(alert, animated: true, completion: nil)
                    }
                }
            }
     }
 }
}
    




