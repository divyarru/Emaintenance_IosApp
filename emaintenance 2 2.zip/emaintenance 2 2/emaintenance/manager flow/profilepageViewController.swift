//
//  profilepageViewController.swift
//  emaintenance
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class profilepageViewController: baseViewController {

    @IBOutlet weak var profilePhotoImage: UIImageView!
    
    @IBOutlet weak var nameTextfield: UITextField!
    @IBOutlet weak var roleTextfield: UITextField!
    @IBOutlet weak var numberTextfield: UITextField!
    
    var profileTwoData : profileTwoModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getAPI()
    }
    @IBAction func backButtonAction(_ sender: UIButton) {
        
      self.navigationController?.popViewController(animated: true)
    
    }
    
    @IBAction func menuButtonAction(_ sender: UIButton) {
        
        self.present(self.menu!, animated: true, completion: nil)
    }

}
extension profilepageViewController{
    
    func getAPI(){
        let apiURL = APIList().urlString(url:.profileTwo)+"username=\(UserDefaultsManager.shared.getUserid() ?? "")"
        self.startIndicator()
        print(apiURL)
           APIHandler().getAPIValues(type: profileTwoModel.self, apiUrl: apiURL, method: "GET") {  [self]  result in switch result {
               case .success(let data):
                   self.profileTwoData = data
                 print(data)
                   if self.profileTwoData.status == true{
                       
                       DispatchQueue.main.async {
                           self.nameTextfield?.text = profileTwoData?.data?.name
                           self.roleTextfield?.text = profileTwoData?.data?.role
                           self.numberTextfield?.text = profileTwoData?.data?.mobnum
                           self.stopIndicator()
                           
                      }
                   }
                   else if self.profileTwoData.status == false{
                       DispatchQueue.main.async {
                           self.stopIndicator()
                           self.showToast(self.profileTwoData.message ?? "Error")
                       }
                       
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                       self.stopIndicator()
                   let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
    }
}


