//
//  menu1ViewController.swift
//  emaintenance
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class menu1ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

   

}
