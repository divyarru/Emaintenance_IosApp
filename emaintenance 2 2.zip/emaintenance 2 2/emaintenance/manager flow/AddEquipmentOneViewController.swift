//
//  AddEquipmentOneViewController.swift
//  emaintenance
//
//  Created by SAIL on 27/10/23.
//

import UIKit

class AddEquipmentOneViewController: baseViewController, UITextFieldDelegate {

    @IBOutlet weak var equipmentNameTextfield: UITextField!
    @IBOutlet weak var serviceTypeTextfield: UITextField!
    @IBOutlet weak var chargeTextfield: UITextField!
    @IBOutlet weak var dateTextfield: UITextField!
    @IBOutlet weak var employeIdTextfield: UITextField!
    @IBOutlet weak var statusTextfield: UITextField!
    
    var addEquipment : addEquipmentOneModel!
    
    var equipmentName = ["5001","5002","5003","5004","5005","5006","6001","6002","6003","6004","6005","6006","7001","7002","7003","7004","7005","7006","8001","8002","8003","8004","8005","8006","9001","9002","9003","9004","9005","9006"]
    let datePicker : UIDatePicker = UIDatePicker()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        dateTextfield.tag = 0
        equipmentNameTextfield.delegate = self
    }
    @IBAction func dateTextFieldBeginEditing(_ sender: UITextField) {
        showDatePicker(tag: sender.tag)
    }
    func showDatePicker(tag: Int){
        //Formate Date
        datePicker.datePickerMode = .date
        
        if #available(iOS 13.4, *) {
            datePicker.preferredDatePickerStyle = .inline
        }
        else {
            datePicker.preferredDatePickerStyle = .wheels
        }
//        datePicker.minimumDate = Calendar.current.date(byAdding: .day, value: 0, to: Date())
//        datePicker.maximumDate = Calendar.current.date(byAdding: .year, value: +30, to: Date())
        //ToolBar
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        
        //done button & cancel button
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(self.donedatePicker(_ :)))
        doneButton.tag = tag
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        
        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.cancelDatePicker(_ :)))
        cancelButton.tag = tag
        toolbar.setItems([cancelButton ,spaceButton,doneButton], animated: false)
        
        
        self.dateTextfield.inputAccessoryView = toolbar
        self.dateTextfield.inputView = datePicker
      
    }
    @objc func cancelDatePicker(_ sender: UIButton){
        self.dateTextfield.text? = ""
        self.view.endEditing(true)
    }

    @objc func donedatePicker(_ sender: UIButton){
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        //datePicker.maximumDate = Calendar.current.date(byAdding: .day, value: -1, to: Date())
//        datePicker.minimumDate = Calendar.current.date(byAdding: .day, value: 0, to: Date())
//        datePicker.maximumDate = Calendar.current.date(byAdding: .year, value: +30, to: Date())
        self.dateTextfield.text = formatter.string(from: datePicker.date)
        self.view.endEditing(true)
    }

   
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == equipmentNameTextfield {
            textField.resignFirstResponder()
            let alert = UIAlertController(title: "", message: "Select Task", preferredStyle: .actionSheet)
            for task in equipmentName {
                alert.addAction(UIAlertAction(title: task, style: .default, handler: { (action) in
                    self.equipmentNameTextfield.text = task
                }))
            }
            alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: { (action) in
                print("Cancelled")
            }))
            alert.popoverPresentationController?.sourceView = self.view
            self.present(alert, animated: true, completion: {
                print("Completion block")
            })
            return false
        }
        return true
    }
    
    
    
    @IBAction func addButton(_ sender: UIButton) {
        if equipmentNameTextfield.text?.isEmpty == true{
            showToast("Enter the equipmentID")
        }else if serviceTypeTextfield.text?.isEmpty == true{
            showToast("Enter the serviceType")
        }else if chargeTextfield.text?.isEmpty == true{
            showToast("Enter the repair charge")
        }else if dateTextfield.text?.isEmpty == true{
            showToast("Enter the date")
        }else if employeIdTextfield.text?.isEmpty == true{
            showToast("Enter the employeId")
        }else if statusTextfield.text?.isEmpty == true{
            showToast("Enter the status")
        }else{
            postAPI()
        }
     }
    
    
    @IBAction func backButtonAction(_ sender: UIButton) {
        
      self.navigationController?.popViewController(animated: true)
     }
    @IBAction func menuButtonAction(_ sender: UIButton) {
        
        self.present(self.menu!, animated: true, completion: nil)
    
    }
    
    
     }
extension AddEquipmentOneViewController{
        
        func postAPI(){
            self.startIndicator()
            let formData = ["eid2":"\(equipmentNameTextfield.text ?? "Error")",
                       "servicetype":"\(serviceTypeTextfield.text ?? "Error")",
                       "servicecharge":"\(chargeTextfield.text ?? "Error")",
                       "empid":"\(employeIdTextfield.text ?? "Error")",
                       "date":"\(dateTextfield.text ?? "Error")",
                       "status":"\(statusTextfield.text ?? "Error")"]
            
            let apiURL = APIList().urlString(url:.addEquipment)
            print(apiURL)
            print(formData)
               APIHandler().postAPIValues(type: addEquipmentOneModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
                   switch result {
                   case .success(let data):
                       DispatchQueue.main.async {
                           print(data)
                           self.stopIndicator()
                           self.showAlert(title: "Success", message: data.message, okActionHandler: {
                               let vc = self.storyboard?.instantiateViewController(withIdentifier: "equipmentViewController") as! equipmentViewController
                               self.navigationController?.pushViewController(vc, animated: true)
                                   })
                       }
                       case .failure(let error):
                       print(error)
                       DispatchQueue.main.async {
                           self.stopIndicator()
                       let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                       alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                           print("JSON Error")
                       })
                       self.present(alert, animated: true, completion: nil)
                       }
                   }
               }
        }
    }

