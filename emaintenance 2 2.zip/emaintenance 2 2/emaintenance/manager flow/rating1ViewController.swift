//
//  rating1ViewController.swift
//  emaintenance
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class rating1ViewController: baseViewController {

    @IBOutlet weak var menuButton: UIButton!
    
    @IBOutlet weak var backButton: UIButton!
    
    
    @IBOutlet weak var jobIdTextfield: UITextField!
    
    @IBOutlet weak var nameTextfield: UITextField!
    
    @IBOutlet weak var commentsTextView: UITextView!
    var rating : ratingModel!
    @IBOutlet var starButtons: [UIButton]!
    var selectedRating: Int = 0

       override func viewDidLoad() {
           super.viewDidLoad()

           
           for (index, button) in starButtons.enumerated() {
               button.tag = index
               button.addTarget(self, action: #selector(starButtonAct(_:)), for: .touchUpInside)
           }
       }

       @objc func starButtonAct(_ sender: UIButton) {
           let selectedIndex = sender.tag
           selectedRating = selectedIndex + 1
           for (index, button) in starButtons.enumerated() {
               button.isSelected = index <= selectedIndex
               let imageName = button.isSelected ? "star.fill" : "star"
               button.setImage(UIImage(systemName: imageName), for: .normal)
           }
           print("Selected rating: \(selectedRating)")

           
       }
    @IBAction func backButtonAction(_ sender: UIButton) {
        
      self.navigationController?.popViewController(animated: true)
    
    }
    
    @IBAction func menuButtonAction(_ sender: UIButton) {
        
        self.present(self.menu!, animated: true, completion: nil)
    
    }
    

    @IBAction func submit(_ sender: UIButton) {
        print("Selected rating: \(selectedRating)")
        if jobIdTextfield.text?.isEmpty == true{
            showToast("Enter the JobId")
        }else if nameTextfield.text?.isEmpty == true{
            showToast("Enter the Name")
        }else if selectedRating == 0{
            showToast("Select the Rating")
        }else if commentsTextView.text?.isEmpty == true{
            showToast("Write comments")
        }else{
            postAPI()
        }
        
    }
    

}
extension rating1ViewController{
    
    func postAPI(){
        
        let formData = ["empid":"\(jobIdTextfield.text ?? "Error")",
                   "name":"\(nameTextfield.text ?? "Error")",
                        "ratingStars":"\(selectedRating)",
                   "comments":"\(commentsTextView.text ?? "Error")"]
        
        self.startIndicator()
        let apiURL = APIList().urlString(url:.ratingOne)
        print(apiURL)
        APIHandler().postAPIValues(type: ratingModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
               switch result {
               case .success(let data):
                   DispatchQueue.main.async {
                       self.rating = data
                       self.stopIndicator()
                       self.showAlert(title: "Success", message: data.message, okActionHandler: {
                           let vc = self.storyboard?.instantiateViewController(withIdentifier: "equipmentViewController") as! equipmentViewController
                           self.navigationController?.pushViewController(vc, animated: true)
                       })
                  
                   }
                 print(data)
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                   let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                       self.stopIndicator()
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
    }
}


