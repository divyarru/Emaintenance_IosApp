//
//  ApiList.swift
//  emaintenance
//
//  Created by SAIL on 19/10/23.
//

import Foundation

struct APIList
{
    
    let BASE_URL = "http://192.168.55.77/testingapi/"
    
    func urlString(url: urlString) -> String
    {
        return BASE_URL + url.rawValue
    }
}

enum urlString: String

{
    
    case loginApi = "login.php?"
    case serviceJob = "servicejob1.php?"
    case serviceJobTwo = "servicejob2.php?"
    case assignWorker = "choose.php?"
    case workstatus = "status.php?"
    case profileOne = "profile1.php?"
    case issue = "issue.php"
    case ratingOne = "rating.php"
    case add = "add.php"
    case addWorker = "add2.php"
    case addEquipment = "equipmentadd2.php?"
    case profileTwo = "profile2.php?"
    case managerLogin = "login2.php?"
    case userLogin = "userlogin.php?"
    case productData = "api.php?"
    case addBuildingData = "addbuilding.php?"
    case addFloorData = "addfloor.php?"
    case addRoomData = "addroom.php?"
    case idData = "id.php?"
    case showEquipmentData = "showequipment.php?"
    case postUserData = "postuser.php"
    case employeDetailsData = "employedetails.php?"
    case getIssueData = "getIssue.php?"
    case getWorkerdata = "getWorker.php?"
    case postAssignData = "postassign.php"
    case closeIssue = "button.php?"
    case WorkerIssue = "workerIssue.php?"
    case GetUserIssueData = "getuserIssue.php?"
    case WorkerCloseIssue = "workerbutton.php?"
}

