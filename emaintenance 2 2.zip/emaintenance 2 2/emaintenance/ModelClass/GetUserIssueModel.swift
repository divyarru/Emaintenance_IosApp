//
//  GetUserIssueModel.swift
//  emaintenance
//
//  Created by SAIL on 20/12/23.
//

import Foundation
struct GetUserIssueModel: Codable {
    let status: Bool
    let message: String
    let data: [GetUserIssueData]
}

// MARK: - Datum
struct GetUserIssueData: Codable {
    let eqname, issue, location: String
    let date: String?
}
