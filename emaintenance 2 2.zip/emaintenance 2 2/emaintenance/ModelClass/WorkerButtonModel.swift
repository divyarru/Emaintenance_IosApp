//
//  WorkerButtonModel.swift
//  emaintenance
//
//  Created by SAIL on 20/12/23.
//

import Foundation
struct WorkerButtonModel: Codable {
    let status: Bool
    let message: String
}
