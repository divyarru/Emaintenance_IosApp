//
//  SuperVisorLoginModel.swift
//  emaintenance
//
//  Created by SAIL on 19/10/23.
//

import Foundation

struct SuperVisorLoginModel: Codable {
    var status: Bool?
    var message: String?
    var data: SuperVisorLogin?
}

// MARK: - DataClass
struct SuperVisorLogin : Codable {
    var id, username, password, role: String?
    var name, dob, mobnum, empid: String?
    var status: String?
}
