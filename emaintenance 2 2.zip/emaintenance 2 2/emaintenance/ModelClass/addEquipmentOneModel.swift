//
//  addEquipmentOneModel.swift
//  emaintenance
//
//  Created by SAIL on 27/10/23.
//

import Foundation
struct addEquipmentOneModel: Codable {
    let status, message: String
}
