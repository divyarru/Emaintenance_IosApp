//
//  employeDetailsModel.swift
//  emaintenance
//
//  Created by SAIL on 14/12/23.
//

import Foundation

// MARK: - Welcome
struct employeDetailsModel: Codable {
    let status: Bool
    let message: String
    let data: [employeDetailsData]
}

// MARK: - Datum
struct employeDetailsData: Codable {
    let name, role, mobnum, action: String
}
