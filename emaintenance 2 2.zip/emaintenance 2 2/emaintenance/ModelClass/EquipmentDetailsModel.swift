//
//  EquipmentDetailsModel.swift
//  emaintenance
//
//  Created by SAIL on 25/10/23.
//

import Foundation

struct EquipmentDetailsModel: Codable {
    var status: Bool?
    var message: String?
    var data: [DetailsEquipment]?
}

// MARK: - Datum
struct DetailsEquipment: Codable {
    var jid, servicetype, servicecharge, empid: String?
    var date: String?
    var status: String?
    var eid2: String?
}


