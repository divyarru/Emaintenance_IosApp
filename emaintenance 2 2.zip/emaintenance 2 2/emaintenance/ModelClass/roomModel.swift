//
//  roomModel.swift
//  emaintenance
//
//  Created by SAIL on 22/11/23.
//

import Foundation
struct roomModel: Codable {
    let status: Bool
    let message: String
    let data: [addRoomData]
}

// MARK: - Datum
struct addRoomData: Codable {
    let room: String
    let floor : String
}
