//
//  postUserModel.swift
//  emaintenance
//
//  Created by SAIL on 14/12/23.
//

import Foundation
struct postUserModel: Codable {
    let message: String
}
