//
//  postAssignModel.swift
//  emaintenance
//
//  Created by SAIL on 15/12/23.
//

import Foundation
struct postaAssignModel: Codable {
    let message: String
}
