//
//  addModel.swift
//  emaintenance
//
//  Created by SAIL on 26/10/23.
//

import Foundation
struct addModel: Codable {
    let status, message: String
}
