//
//  productModel.swift
//  emaintenance
//
//  Created by SAIL on 18/11/23.
//

import Foundation

// MARK: - Welcome
struct productModel: Codable {
    let status: Bool
    let message: String
    let data: [productData]
}

// MARK: - Datum
struct productData: Codable {
    let eid,name: String
    let brand: String
    let type, price, installation: String
    let warranty: String
    let warrantyend: String
}




