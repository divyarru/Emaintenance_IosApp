//
//  workStatusModel.swift
//  emaintenance
//
//  Created by SAIL on 25/10/23.
//

import Foundation
struct workStatusModel: Codable {
    var status: Bool?
    var message: String?
    var data: [workStatus]?
}

// MARK: - Datum
struct workStatus: Codable {
    var empid, date: String?
    var status: String?
}

