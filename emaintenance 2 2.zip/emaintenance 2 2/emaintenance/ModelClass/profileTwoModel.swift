//
//  profileTwoModel.swift
//  emaintenance
//
//  Created by SAIL on 02/11/23.
//

import Foundation
struct profileTwoModel: Codable {
    var status: Bool?
    var message: String?
    var data: profileTwoData?
}

// MARK: - DataClass
struct profileTwoData: Codable {
    var role, name, mobnum: String?
}
