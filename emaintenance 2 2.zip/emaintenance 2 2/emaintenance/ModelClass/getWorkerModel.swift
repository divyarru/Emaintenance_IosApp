//
//  getWorkerModel.swift
//  emaintenance
//
//  Created by SAIL on 15/12/23.
//

import Foundation
struct getWorkerModel: Codable {
    let status: Bool
    let message: String
    let data: [getWorkerData]
}

// MARK: - Datum
struct getWorkerData: Codable {
    let name: String
}
