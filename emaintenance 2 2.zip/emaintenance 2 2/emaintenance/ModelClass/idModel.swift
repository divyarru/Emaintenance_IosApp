//
//  idModel.swift
//  emaintenance
//
//  Created by SAIL on 18/11/23.
//

import Foundation
struct idModel: Codable {
    let status: Bool
    let message: String
    let data: [idData]
}

// MARK: - Datum
struct idData: Codable {
    let eid, name: String
}
