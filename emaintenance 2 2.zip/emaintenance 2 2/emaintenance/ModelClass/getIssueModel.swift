//
//  getIssueModel.swift
//  emaintenance
//
//  Created by SAIL on 15/12/23.
//

import Foundation
struct getIssueModel: Codable {
    let status: Bool
    let message: String
    let data: [getIssueData]
}

// MARK: - Datum
struct getIssueData: Codable {
    let eqname,iid, issue, location: String
    let date: String?
}
