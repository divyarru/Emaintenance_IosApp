//
//  userLoginModel.swift
//  emaintenance
//
//  Created by SAIL on 18/11/23.
//

import Foundation

// MARK: - Welcome
struct userLoginModel: Codable {
    let status: Bool
    let message: String
    let data: userLoginData
}

// MARK: - DataClass
struct userLoginData: Codable {
    let id, username, password, role: String
    let name, dob, mobnum, empid: String
    let status: String
}
