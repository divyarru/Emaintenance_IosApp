//
//  showEquipmentModel.swift
//  emaintenance
//
//  Created by SAIL on 14/12/23.
//

import Foundation
struct showEquipmentModel: Codable {
    let status: Bool
    let message: String
    let data: [showEquipmentData]
}

// MARK: - Datum
struct showEquipmentData: Codable {
    let eidd: String
    let equipment: String
    let building, room: String
}


