//
//  issueModel.swift
//  emaintenance
//
//  Created by SAIL on 26/10/23.
//

import Foundation
struct issueModel: Codable {
    let message: String
}
