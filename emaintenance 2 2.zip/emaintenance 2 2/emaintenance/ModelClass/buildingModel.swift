//
//  buildingModel.swift
//  emaintenance
//
//  Created by SAIL on 22/11/23.
//

import Foundation
struct buildingModel: Codable {
    let status: Bool
    let message: String
    let data: [addBuildingData]
}

// MARK: - Datum
struct addBuildingData: Codable {
    let building: String
}
