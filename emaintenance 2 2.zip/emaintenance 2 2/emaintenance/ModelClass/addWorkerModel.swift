//
//  addWorkerModel.swift
//  emaintenance
//
//  Created by SAIL on 27/10/23.
//

import Foundation
struct addWorkerModel: Codable {
    let status, message: String
}
