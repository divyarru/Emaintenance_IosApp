//
//  floorModel.swift
//  emaintenance
//
//  Created by SAIL on 22/11/23.
//

import Foundation
struct floorModel: Codable {
    let status: Bool
    let message: String
    let data: [addFloorData]
}

// MARK: - Datum
struct addFloorData: Codable {
    let floor: String
}
