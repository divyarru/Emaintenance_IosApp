//
//  profileOneModel.swift
//  emaintenance
//
//  Created by SAIL on 25/10/23.
//

import Foundation

// MARK: - Welcome
struct profileOneModel: Codable {
    var status: Bool?
    var message: String?
    var data: profileOneData?
}

// MARK: - DataClass
struct profileOneData: Codable {
    var role, name, mobnum: String?
}
