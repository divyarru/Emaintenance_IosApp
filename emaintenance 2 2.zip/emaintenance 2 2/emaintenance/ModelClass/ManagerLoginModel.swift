//
//  ManagerLoginModel.swift
//  emaintenance
//
//  Created by SAIL on 02/11/23.
//

import Foundation
struct ManagerLoginModel: Codable {
    var status: Bool?
    var message: String?
    var data: ManagerLoginData?
}

// MARK: - DataClass
struct ManagerLoginData: Codable {
    var id, username, password, role: String?
    var name, dob, mobnum, empid: String?
    var status: String?
}
