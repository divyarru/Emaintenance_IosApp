//
//  EquipmentServicesModel.swift
//  emaintenance
//
//  Created by SAIL on 19/10/23.
//

import Foundation

struct EquipmentServicesModel : Codable {
    let status : Bool?
    let message : String?
    let data : [Data]?

    enum CodingKeys: String, CodingKey {

        case status = "status"
        case message = "message"
        case data = "data"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        status = try values.decodeIfPresent(Bool.self, forKey: .status)
        message = try values.decodeIfPresent(String.self, forKey: .message)
        data = try values.decodeIfPresent([Data].self, forKey: .data)
    }

}

struct Data : Codable {
    let jid : String?
    let servicetype : String?
    let servicecharge : String?
    let date : String?
    let status : String?
    let eid2 : String?

    enum CodingKeys: String, CodingKey {

        case jid = "jid"
        case servicetype = "servicetype"
        case servicecharge = "servicecharge"
        case date = "date"
        case status = "status"
        case eid2 = "eid2"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        jid = try values.decodeIfPresent(String.self, forKey: .jid)
        servicetype = try values.decodeIfPresent(String.self, forKey: .servicetype)
        servicecharge = try values.decodeIfPresent(String.self, forKey: .servicecharge)
        date = try values.decodeIfPresent(String.self, forKey: .date)
        status = try values.decodeIfPresent(String.self, forKey: .status)
        eid2 = try values.decodeIfPresent(String.self, forKey: .eid2)
    }

}

