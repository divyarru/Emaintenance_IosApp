//
//  closeIssueModel.swift
//  emaintenance
//
//  Created by SAIL on 18/12/23.
//

import Foundation
struct closeIssueModel: Codable {
    let message: String
    let status: Bool
  
}
