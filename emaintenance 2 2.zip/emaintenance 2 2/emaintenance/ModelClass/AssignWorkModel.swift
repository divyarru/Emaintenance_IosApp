//
//  AssignWorkModel.swift
//  emaintenance
//
//  Created by SAIL on 20/10/23.
//

import Foundation

// MARK: - Welcome
struct AssignWork: Codable {
    var status: Bool?
    var message: String?
    var data: [assignWorkData]?
}

// MARK: - Datum
struct assignWorkData: Codable {
    let mobnum, name: String
}
