//
//  roomViewController.swift
//  emaintenance
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class RoomViewController : baseViewController {
    
    @IBOutlet weak var tableView: UITableView!
            
    @IBOutlet weak var back: UIButton!
            
    @IBOutlet weak var menuButton: UIButton!
    @IBOutlet weak var searchBarOutlet: UISearchBar!
    
    //var roomData = ["Room 1","Room 2","Room 3","Room 4","Room 5","Room 6","Room 7","Room 8","Room 9","Room 10"]
    var filteredRoomData: [addRoomData] = []
    var addRoomData: roomModel!
    var floorData = ""

    override func viewDidLoad() {
           super.viewDidLoad()
           searchBarOutlet.delegate = self
        getroomAPI()
    }
    
    
    @IBAction func backButtonAction(_ sender: UIButton) {
        
        self.navigationController?.popViewController(animated: true)
    
    }
    @IBAction func menuButtonAction(_ sender: UIButton) {
        
        self.present(self.menu!, animated: true, completion: nil)
    
    }
}
    extension RoomViewController{
        
        func getroomAPI(){
            self.startIndicator()
            let apiURL = APIList().urlString(url:.addRoomData)
            print(apiURL)
               APIHandler().getAPIValues(type: roomModel.self, apiUrl: apiURL, method: "GET") {  result in
                   switch result {
                   case .success(let data):
                       self.addRoomData = data
                     print(data)
                       if self.addRoomData.status == true{
                           
                           DispatchQueue.main.async { [self] in
                               self.stopIndicator()
                               filteredRoomData = addRoomData?.data.filter{
                                   $0.floor == floorData
                               } ?? []
                               self.tableView.reloadData()
                          }
                       }
                       else if self.addRoomData.status == false{
                           DispatchQueue.main.async {
                               self.stopIndicator()
                          
                               self.showToast(self.addRoomData.message )
                           }
                       }
                       case .failure(let error):
                       print(error)
                       DispatchQueue.main.async {
                           self.stopIndicator()
                       let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                       alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                           print("JSON Error")
                       })
                       self.present(alert, animated: true, completion: nil)
                       }
                   }
               }
        }
    }

extension RoomViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            // If the search text is empty, show all buildings
            filteredRoomData = addRoomData?.data ?? []
        } else {
            filteredRoomData = addRoomData?.data.filter { $0.room.lowercased().contains(searchText.lowercased()) } ?? []
        }
        tableView.reloadData()
    }
    
}

extension RoomViewController : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredRoomData.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "RoomTableViewCell") as! RoomTableViewCell
        cell.backgroundColor = UIColor.white
        cell.View.layer.borderColor = UIColor.black.cgColor
        cell.View.layer.borderWidth = 1
        cell.View.layer.cornerRadius = 8
        cell.View.clipsToBounds = true
        cell.Label.text = filteredRoomData[indexPath.row].room
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let ViewController = self.storyboard?.instantiateViewController(withIdentifier: "equipmentidViewController") as! equipmentidViewController
        self.navigationController?.pushViewController(ViewController, animated: true)
    }
    
}

class RoomTableViewCell : UITableViewCell{
    
    @IBOutlet weak var View: UIView!
    @IBOutlet weak var Label: UILabel!
    
}

