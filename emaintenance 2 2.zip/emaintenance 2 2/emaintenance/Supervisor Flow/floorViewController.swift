//
//  floorViewController.swift
//  emaintenance
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class floorViewController: baseViewController {
 
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var back: UIButton!
    @IBOutlet weak var menubutton: UIButton!
    @IBOutlet weak var searchBarOutlet: UISearchBar!
    
    //var floorData = ["Floor 1","Floor 2","Floor 3","Floor 4","Floor 5","Floor 6"]
    var filteredFloorData: [addFloorData] = []
    var addFloorData: floorModel!
    
    override func viewDidLoad() {
           super.viewDidLoad()
           searchBarOutlet.delegate = self
        getfloorAPI()
    }
    
    
    @IBAction func backButtonAction(_ sender: UIButton) {
        
    self.navigationController?.popViewController(animated: true)
    
    }
    @IBAction func menuButtonAction(_ sender: UIButton) {
    
    self.present(self.menu!, animated: true, completion: nil)
    
       }
    }
extension floorViewController{
    
    func getfloorAPI(){
        self.startIndicator()
        let apiURL = APIList().urlString(url:.addFloorData)
        print(apiURL)
           APIHandler().getAPIValues(type: floorModel.self, apiUrl: apiURL, method: "GET") {  result in
               switch result {
               case .success(let data):
                   self.addFloorData = data
                 print(data)
                   if self.addFloorData.status == true{
                       
                       DispatchQueue.main.async { [self] in
                           self.stopIndicator()
                           filteredFloorData = addFloorData?.data ?? []
                           self.tableView.reloadData()
                      }
                   }
                   else if self.addFloorData.status == false{
                       DispatchQueue.main.async {
                           self.stopIndicator()
                      
                           self.showToast(self.addFloorData.message )
                       }
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                       self.stopIndicator()
                   let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
    }
}

extension floorViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            // If the search text is empty, show all buildings
            filteredFloorData = addFloorData?.data ?? []
        } else {
            filteredFloorData = addFloorData?.data.filter { $0.floor.lowercased().contains(searchText.lowercased()) } ?? []
        }
        tableView.reloadData()
    }
    
}

extension floorViewController : UITableViewDelegate, UITableViewDataSource{
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return filteredFloorData.count
     }
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell =  tableView.dequeueReusableCell(withIdentifier: "floorTableViewCell") as! floorTableViewCell
         cell.backgroundColor = UIColor.white
         cell.View.layer.borderColor = UIColor.black.cgColor
         cell.View.layer.borderWidth = 1
         cell.View.layer.cornerRadius = 8
         cell.View.clipsToBounds = true
         cell.Label.text = filteredFloorData[indexPath.row].floor
         
         return cell
     }
     
     func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
         return 80
     }
     func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         
         let ViewController = self.storyboard?.instantiateViewController(withIdentifier: "RoomViewController") as! RoomViewController
         ViewController.floorData = filteredFloorData[indexPath.row].floor
         self.navigationController?.pushViewController(ViewController, animated: true)
     }
     
 }
 class floorTableViewCell : UITableViewCell{
     
     @IBOutlet weak var View: UIView!
     @IBOutlet weak var Label: UILabel!
     
 }
