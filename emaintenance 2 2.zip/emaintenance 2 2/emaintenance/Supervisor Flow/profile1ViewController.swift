//
//  profile1ViewController.swift
//  emaintenance
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class profile1ViewController: baseViewController {
    
    @IBOutlet weak var profileView: UIImageView!
    
    @IBOutlet weak var nameTextfield: UITextField!
    @IBOutlet weak var roleTextfield: UITextField!
    @IBOutlet weak var mobileTextfield: UITextField!
    
    var profileOneData : profileOneModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getAPI()
    }
    @IBAction func backButtonAction(_ sender: UIButton) {
        
      self.navigationController?.popViewController(animated: true)
     }
    
    @IBAction func menuButtonAction(_ sender: UIButton) {
        
        self.present(self.menu!, animated: true, completion: nil)
     }

}
extension profile1ViewController{
    
    func getAPI(){
        self.startIndicator()
        let apiURL = APIList().urlString(url:.profileOne)+"username=\(UserDefaultsManager.shared.getUserid() ?? "")"
        
        print(apiURL)
           APIHandler().getAPIValues(type: profileOneModel.self, apiUrl: apiURL, method: "GET") {  [self]  result in switch result {
               case .success(let data):
                   self.profileOneData = data
                 print(data)
                   if self.profileOneData.status == true{
                       
                       DispatchQueue.main.async {
                           self.nameTextfield?.text = profileOneData?.data?.name
                           self.roleTextfield?.text = profileOneData?.data?.role
                           self.mobileTextfield?.text = profileOneData?.data?.mobnum
                           
                           self.stopIndicator()
                           
                      }
                   }
                   else if self.profileOneData.status == false{
                       DispatchQueue.main.async {
                           self.stopIndicator()
                           self.showToast(self.profileOneData.message ?? "Error")
                       }
                       
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                       self.stopIndicator()
                   let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
    }
}

