//
//  equdetails2ViewController.swift
//  emaintenance
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class equdetails2ViewController: baseViewController {

    @IBOutlet weak var tableView: UITableView!{
        didSet{
            tableView.delegate = self
            tableView.dataSource = self
        }
    }
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var menuButton: UIButton!
    @IBOutlet weak var jobHistoryView: UIView!
    @IBOutlet weak var workAssignButton: UIButton!
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var brandLabel: UILabel!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var purchaseLabel: UILabel!
    @IBOutlet weak var warrantyEndLabel: UILabel!
    @IBOutlet weak var warrantyLabel: UILabel!

    var equipmentDetailsData : EquipmentDetailsModel!
    var selectedServices =  [DetailsEquipment]()
    var name = ""
    var brand = ""
    var type = ""
    var price = ""
    var purchase = ""
    var warrantyEnd = ""
    var warranty = ""
    var eidData = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.initialLoads()
        
    }
    func initialLoads(){
        print("brand --> : \(brand), type --> : \(type), price --> : \(price), purchase --> : \(purchase), warrantyEnd --> : \(warrantyEnd), warranty --> : \(warranty)")
        nameLabel.text = name
        brandLabel.text = brand
        typeLabel.text = type
        priceLabel.text = price
        purchaseLabel.text = purchase
        warrantyEndLabel.text = warrantyEnd
        warrantyLabel.text = warranty
        jobHistoryView.layer.borderColor = UIColor.black.cgColor
        jobHistoryView.layer.borderWidth = 1
        jobHistoryView.layer.cornerRadius = 5
        jobHistoryView.clipsToBounds = true
        self.getAPI()
        if  UserDefaultsManager.shared.getUserName() == "Manager" {
            workAssignButton.isHidden = true
        }else {
            workAssignButton.isHidden = false
        }
    }
    
    
    @IBAction func backButtonAction(_ sender: UIButton) {
        
      self.navigationController?.popViewController(animated: true)
    
    }
    @IBAction func menuButtonAction(_ sender: UIButton) {
        
        self.present(self.menu!, animated: true, completion: nil)
    
    }
    @IBAction func workAssignAction(_ sender: UIButton) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "chooseViewController") as! chooseViewController
        self.navigationController?.pushViewController(vc, animated: true)
    
    }
  

}
extension equdetails2ViewController{
    
    func getAPI(){
        self.startIndicator()
        let apiURL = APIList().urlString(url:.serviceJobTwo)
        print(apiURL)
        APIHandler().getAPIValues(type: EquipmentDetailsModel.self, apiUrl: apiURL, method: "GET") { [self]  result in
               switch result {
               case .success(let data):
                   self.equipmentDetailsData = data
                 print(data)
                   if self.equipmentDetailsData.status == true{
                       DispatchQueue.main.async { [self] in
                           selectedServices = data.data?.filter{
                               ($0.eid2 == eidData)
                           } ?? []
                           if selectedServices.count == 0 {
                               showToast("No data found for the specified ID")
                           }
                           self.stopIndicator()
                           self.tableView.reloadData()
                      }
                       
                   }
                   else if self.equipmentDetailsData.status == false{
                       DispatchQueue.main.async {
                           self.stopIndicator()
                       self.showToast(self.equipmentDetailsData.message ?? "Error")
                       }
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                       self.stopIndicator()
                   let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
    }
}

extension equdetails2ViewController : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.selectedServices.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "equdetailsTwoTableViewCell") as! equdetailsTwoTableViewCell
        cell.backgroundColor = UIColor.white
        cell.View.layer.borderColor = UIColor.black.cgColor
        cell.View.layer.borderWidth = 1
        cell.View.layer.cornerRadius = 8
        cell.View.clipsToBounds = true
        
        let ServicesIDData = selectedServices[indexPath.row]
        cell.dateDetailLabel.text = ServicesIDData.date
                    cell.serviceTypeDetailLabel.text = ServicesIDData.servicetype
                    cell.serviceChargeDetailLabel.text = ServicesIDData.servicecharge
                    cell.statusDetailLabel.text = ServicesIDData.status
        
        
        cell.empIdDetailLabel.text = ServicesIDData.empid
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    
}
class equdetailsTwoTableViewCell : UITableViewCell{
    
    @IBOutlet weak var View: UIView!
    @IBOutlet weak var dateDetailLabel: UILabel!
    @IBOutlet weak var serviceTypeDetailLabel: UILabel!
    @IBOutlet weak var serviceChargeDetailLabel: UILabel!
    @IBOutlet weak var statusDetailLabel: UILabel!
    @IBOutlet weak var empIdDetailLabel: UILabel!

}


