//
//  equdetailsViewController.swift
//  emaintenance
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class equdetailsViewController: baseViewController {

    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var brandLabel: UILabel!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var purchaseLabel: UILabel!
    @IBOutlet weak var warrantyLabel: UILabel!
    
    @IBOutlet weak var warrantyEndLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var menuButton: UIButton!
    @IBOutlet weak var jobHistoryView: UIView!
    @IBOutlet weak var replaceButton: UIButton!

    var idDetailsData = ""
    var productData: productModel!
    

    var EquipmentServices: EquipmentServicesModel!
    var selectedServices =  [Data]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getAPI()
        self.initialLoads()
        print(idDetailsData)
       if  UserDefaultsManager.shared.getUserName() == "Manager" {
           replaceButton.setTitle("Next", for: .normal)
       }
        
    }
    func initialLoads(){
        getProductAPI()
        jobHistoryView.layer.borderColor = UIColor.black.cgColor
        jobHistoryView.layer.borderWidth = 1
        jobHistoryView.layer.cornerRadius = 5
        jobHistoryView.clipsToBounds = true
    }
    
    
    @IBAction func backButtonAction(_ sender: UIButton) {
        
      self.navigationController?.popViewController(animated: true)
    
    }
    @IBAction func menuButtonAction(_ sender: UIButton) {
        
        self.present(self.menu!, animated: true, completion: nil)
    
    }
    @IBAction func replaceButtonAction(_ sender: UIButton) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "equdetails2ViewController") as! equdetails2ViewController
        if let product = productData.data.first(where: { $0.eid == idDetailsData }) {
            vc.name = product.name
            vc.brand = "\(product.brand )"
            vc.type = product.type 
            vc.price = "\(product.price )"
            vc.purchase = "\(product.installation )"
            vc.warrantyEnd = "\(product.warrantyend )"
            vc.warranty = product.warranty
            
        }
        vc.eidData = idDetailsData
        self.navigationController?.pushViewController(vc, animated: true)
    
    }
  

}
extension equdetailsViewController{
    
        func getProductAPI(){
            let apiURL = APIList().urlString(url:.productData)+"username=\(UserDefaultsManager.shared.getUserid() ?? "")"
            self.startIndicator()
            print(apiURL)
               APIHandler().getAPIValues(type: productModel.self, apiUrl: apiURL, method: "GET") {  [self]  result in switch result {
                   case .success(let data):
                       self.productData = data
                    
                       if self.productData.status == true{
                           
                           DispatchQueue.main.async {
                               if let product = productData.data.first(where: { $0.eid == idDetailsData }) {
                                   print(product)
                                   self.nameLabel.text = product.name
                                   self.brandLabel.text = "\(product.brand)"
                                   self.typeLabel.text = product.type
                                   self.priceLabel.text = "\(product.price)"
                                   self.purchaseLabel.text = "\(product.installation)"
                                   self.warrantyEndLabel.text = "\(product.warrantyend)"
                                   self.warrantyLabel.text = product.warranty
                               }
                               
                           }
                       }
                       else if self.productData.status == false{
                           DispatchQueue.main.async {
                               self.stopIndicator()
                               self.showToast(self.productData.message )
                           }
                           
                       }
                       case .failure(let error):
                       print(error)
                       DispatchQueue.main.async {
                           self.stopIndicator()
                       let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                       alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                           print("JSON Error")
                       })
                       self.present(alert, animated: true, completion: nil)
                       }
                   }
               }
        }
    }


extension equdetailsViewController{
    
    func getAPI(){
        self.startIndicator()
        let apiURL = APIList().urlString(url:.serviceJob)
        print(apiURL)
           APIHandler().getAPIValues(type: EquipmentServicesModel.self, apiUrl: apiURL, method: "GET") {  result in
               switch result {
               case .success(let data):
                   self.EquipmentServices = data
                 print(data)
                   if self.EquipmentServices.status == true{
                       
                       DispatchQueue.main.async { [self] in
                           selectedServices = data.data?.filter{
                               ($0.eid2 == idDetailsData)
                           } ?? []
                           if selectedServices.count == 0 {
                               showToast("No data found for the specified ID")
                           }
                           self.stopIndicator()
                           self.tableView.reloadData()
                      }
                       
                   }
                   else if self.EquipmentServices.status == false{
                       DispatchQueue.main.async {
                       self.stopIndicator()
                       self.showToast(self.EquipmentServices.message ?? "Error")
                       }
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                       self.stopIndicator()
                   let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
    }
}


extension equdetailsViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        self.selectedServices.count
             
       
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "equdetailsTableViewCell") as! equdetailsTableViewCell
        cell.backgroundColor = UIColor.white
        cell.View.layer.borderColor = UIColor.black.cgColor
        cell.View.layer.borderWidth = 1
        cell.View.layer.cornerRadius = 8
        cell.View.clipsToBounds = true

        let ServicesIDData = selectedServices[indexPath.row]
        cell.dateDetailLabel.text = ServicesIDData.date
                    cell.serviceTypeDetailLabel.text = ServicesIDData.servicetype
                    cell.serviceChargeDetailLabel.text = ServicesIDData.servicecharge
                    cell.statusDetailLabel.text = ServicesIDData.status
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    
}
class equdetailsTableViewCell : UITableViewCell{
    
    @IBOutlet weak var View: UIView!
    @IBOutlet weak var dateDetailLabel: UILabel!
    @IBOutlet weak var serviceTypeDetailLabel: UILabel!
    @IBOutlet weak var serviceChargeDetailLabel: UILabel!
    @IBOutlet weak var statusDetailLabel: UILabel!
}

