//
//  buildingViewController.swift
//  emaintenance
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class buildingViewController: baseViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var back: UIButton!
    @IBOutlet weak var menuButton: UIButton!
    @IBOutlet weak var searchBarOutlet: UISearchBar!
    
//    var buildingData = ["Building 1","Building 2","Building 3","Building 4","Building 5"]
    
    var filteredBuildingData: [addBuildingData] = []
    var addBuildingData: buildingModel!

    override func viewDidLoad() {
           super.viewDidLoad()
           searchBarOutlet.delegate = self
        getbuildingAPI()
    }
    
    @IBAction func backButtonAction(_ sender: UIButton) {
        
      self.navigationController?.popViewController(animated: true)
    
    }
    @IBAction func menuButtonAction(_ sender: UIButton) {
        
        self.present(self.menu!, animated: true, completion: nil)
    
    }
}
extension buildingViewController{
    
    func getbuildingAPI(){
        self.startIndicator()
        let apiURL = APIList().urlString(url:.addBuildingData)
        print(apiURL)
           APIHandler().getAPIValues(type: buildingModel.self, apiUrl: apiURL, method: "GET") {  result in
               switch result {
               case .success(let data):
                   self.addBuildingData = data
                 print(data)
                   if self.addBuildingData.status == true{
                       
                       DispatchQueue.main.async { [self] in
                           self.stopIndicator()
                           filteredBuildingData = addBuildingData?.data ?? []
                           self.tableView.reloadData()
                      }
                   }
                   else if self.addBuildingData.status == false{
                       DispatchQueue.main.async {
                           self.stopIndicator()
                      
                           self.showToast(self.addBuildingData.message )
                       }
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                       self.stopIndicator()
                   let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
    }
}

extension buildingViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            // If the search text is empty, show all buildings
            filteredBuildingData = addBuildingData?.data ?? []
        } else {
            filteredBuildingData = addBuildingData?.data.filter { $0.building.lowercased().contains(searchText.lowercased()) } ?? []
        }
        tableView.reloadData()
    }
}


extension buildingViewController : UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return filteredBuildingData.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "tabviewCell") as! tabviewCell
        cell.backgroundColor = UIColor.white
        cell.View.layer.borderColor = UIColor.black.cgColor
        cell.View.layer.borderWidth = 1
        cell.View.layer.cornerRadius = 8
        cell.View.clipsToBounds = true
        cell.Label.text = filteredBuildingData[indexPath.row].building
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let ViewController = self.storyboard?.instantiateViewController(withIdentifier: "floorViewController") as! floorViewController
        self.navigationController?.pushViewController(ViewController, animated: true)
    }
    
}
class tabviewCell : UITableViewCell{
    
    @IBOutlet weak var View: UIView!
    @IBOutlet weak var Label: UILabel!
    
}
