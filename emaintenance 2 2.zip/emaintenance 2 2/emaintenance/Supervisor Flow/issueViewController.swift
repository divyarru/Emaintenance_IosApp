//
//  issueViewController.swift
//  emaintenance
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class issueViewController: baseViewController, UITextFieldDelegate{

    @IBOutlet weak var menuButton: UIButton!
    @IBOutlet weak var backButton: UIButton!
    
    
    @IBOutlet weak var equipmentIDTextfield: UITextField!
    @IBOutlet weak var equipmentNameTextfield: UITextField!
    @IBOutlet weak var dateTextfield: UITextField!
    @IBOutlet weak var issueTextfield: UITextField!
    @IBOutlet weak var locationTextView: UITextView!
    
    var issue : issueModel!
    var getIdList: [idData] = []
    var idData : idModel!
    var userID = ""
    let datePicker : UIDatePicker = UIDatePicker()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getAPI()
        equipmentIDTextfield.delegate = self

        
    
    }
    
    

    @IBAction func backButtonAction(_ sender: UIButton) {
        
      self.navigationController?.popViewController(animated: true)
    
    }
    @IBAction func issueDetailsAction(_ sender: UIButton) {
        
        self.present(self.menu!, animated: true, completion: nil)
    
    }
    @IBAction func submitButtonAction(_ sender: UIButton) {
        if equipmentIDTextfield.text?.isEmpty == true{
            showToast("Equipment Id Required")
        }else if equipmentNameTextfield.text?.isEmpty == true{
            showToast("Equipment Name Required")
        }else if issueTextfield.text?.isEmpty == true{
            showToast("Issue type Required")
        }else if locationTextView.text?.isEmpty == true{
            showToast("Location Required")
        }else{
            postAPI()
        }
        
    
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == equipmentIDTextfield {
            textField.resignFirstResponder()
            let alert = UIAlertController(title: "", message: "Select Location", preferredStyle: .actionSheet)
            for place in getIdList {
                alert.addAction(UIAlertAction(title: place.eid, style: .default, handler: { (action) in
                    self.equipmentIDTextfield.text = place.eid
                }))
            }
            
            alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: { (action) in
                print("Cancelled")
            }))
            
            alert.popoverPresentationController?.sourceView = self.view
            self.present(alert, animated: true, completion: {
                print("completion block")
            })
            return false
        }
        return true
    }
    @IBAction func dateTextFieldBeginEditing(_ sender: UITextField) {
        showDatePicker(tag: sender.tag)
    }
    
    func showDatePicker(tag: Int){
        datePicker.datePickerMode = .date
        
        if #available(iOS 13.4, *) {
            datePicker.preferredDatePickerStyle = .inline
        }
        else {
            datePicker.preferredDatePickerStyle = .wheels
        }
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(self.donedatePicker(_ :)))
        doneButton.tag = tag
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        
        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.cancelDatePicker(_ :)))
        cancelButton.tag = tag
        toolbar.setItems([cancelButton ,spaceButton,doneButton], animated: false)
        self.dateTextfield.inputAccessoryView = toolbar
        self.dateTextfield.inputView = datePicker
    }
    
    @objc func cancelDatePicker(_ sender: UIButton){
        self.dateTextfield.text? = ""
        self.view.endEditing(true)
    }
    
    @objc func donedatePicker(_ sender: UIButton){
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        self.dateTextfield.text = formatter.string(from: datePicker.date)
        self.view.endEditing(true)
    }
    
//    @IBAction func menuButtonAction(_ sender: UIButton) {
//
//        self.present(self.menu!, animated: true, completion: nil)
//
//    }

}
extension issueViewController{
        
        func getAPI(){
            self.startIndicator()
            let apiURL = APIList().urlString(url:.idData)
            print(apiURL)
               APIHandler().getAPIValues(type: idModel.self, apiUrl: apiURL, method: "GET") {  result in
                   switch result {
                   case .success(let data):
                       DispatchQueue.main.async {
                           self.getIdList = data.data
                           self.stopIndicator()
                       }
                       case .failure(let error):
                       print(error)
                       DispatchQueue.main.async {
                           self.stopIndicator()
                       let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                       alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                           print("JSON Error")
                       })
                       self.present(alert, animated: true, completion: nil)
                       }
                   }
               }
        }
            
    
    
    
    func postAPI(){
        
        let formData = ["eqid":"\(equipmentIDTextfield.text ?? "")",
                   "eqname":"\(equipmentNameTextfield.text ?? "")",
                   "issue":"\(issueTextfield.text ?? "")","user_id": userID,
                   "location":"\(locationTextView.text ?? "")"]
        
        self.startIndicator()
        let apiURL = APIList().urlString(url:.issue)
        print(apiURL)
           APIHandler().postAPIValues(type: issueModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
               switch result {
               case .success(let data):
                   self.issue = data
                   DispatchQueue.main.async {
                   self.stopIndicator()
                       self.showToast(self.issue.message)
                       self.showAlert(title: "Details", message: self.issue.message) {
                               }
                   }
                 print(data)
                   case .failure(let error):
                   
                   print(error)
                   DispatchQueue.main.async {
                       self.stopIndicator()
                       self.showToast("failure")
                   let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                      
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
    }
}
