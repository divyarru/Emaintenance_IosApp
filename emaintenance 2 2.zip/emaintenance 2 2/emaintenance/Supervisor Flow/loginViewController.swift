//
//  loginViewController.swift
//  emaintenance
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class loginViewController: baseViewController {
    
    @IBOutlet weak var titleLabelOutlet: UILabel!
    @IBOutlet weak var userNameOutlet: UITextField!
    @IBOutlet weak var passwordOutlet: UITextField!
    @IBOutlet weak var backButton: UIButton!
    
    var iconClick = true
    var logInDetails : SuperVisorLoginModel!
    var ManagerLoginData : ManagerLoginModel!
    var userLoginData : userLoginModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if UserDefaultsManager.shared.getUserName() == "SuperVisor"{
            titleLabelOutlet.text = "Welcome SuperVisor!"
            
        }else if UserDefaultsManager.shared.getUserName() == "Manager"{
            titleLabelOutlet.text = "Welcome Manager!"
        }else if UserDefaultsManager.shared.getUserName() == "User"{
            titleLabelOutlet.text = "Welcome User!"
        }else {
            titleLabelOutlet.text = "Welcome Worker!"
        }
        
        
    }
    
    @IBAction func eyeButton(_ sender: UIButton) {
      
            if iconClick {
                passwordOutlet.isSecureTextEntry = false
            } else
        {
                passwordOutlet.isSecureTextEntry = true
            }
            iconClick = !iconClick
        
    }
    
    @IBAction func backButtonAction(_ sender: UIButton) {
        
      self.navigationController?.popViewController(animated: true)
    
    }
    
   
    @IBAction func login(_ sender: UIButton) {
        
        if userNameOutlet.text?.isEmpty == true {
            self.showToast("Enter the UserName")
        }else if passwordOutlet.text?.isEmpty == true {
            self.showToast("Enter the Password")
        }else {
            self.GetAPI()
//            let vc = self.storyboard?.instantiateViewController(withIdentifier: "equipmentViewController") as! equipmentViewController
//            self.navigationController?.pushViewController(vc, animated: true)
        }
        
    }
    
}

// MARK: Api Integration
extension loginViewController{
    
    func GetAPI(){
        self.startIndicator()
        if UserDefaultsManager.shared.getUserName() == "SuperVisor"{
            
            let apiURL = APIList().urlString(url:.loginApi)+"username=\(userNameOutlet.text ?? "")&password=\(passwordOutlet.text ?? "")"
            print(apiURL)
            APIHandler().getAPIValues(type: SuperVisorLoginModel.self, apiUrl: apiURL, method: "GET") { [self]  result in
                   switch result {
                   case .success(let data):
                       self.logInDetails = data
                     print(data)
                       if self.logInDetails.status == true{
                           DispatchQueue.main.async {
                               self.stopIndicator()
                               UserDefaultsManager.shared.saveUserId(userNameOutlet.text ?? "")
                               let vc = self.storyboard?.instantiateViewController(withIdentifier: "equipmentViewController") as! equipmentViewController
                               self.navigationController?.pushViewController(vc, animated: true)
                          }
                       }
                       else if self.logInDetails.status == false{
                           DispatchQueue.main.async {
                               self.stopIndicator()
                           print(self.logInDetails.message!)
                           showToast(self.logInDetails.message ?? "Error")
                           }
                       }
                       case .failure(let error):
                       print(error)
                       DispatchQueue.main.async {
                           self.stopIndicator()
                       let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                       alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                           print("JSON Error")
                       })
                       self.present(alert, animated: true, completion: nil)
                       }
                   }
               }
        }else if UserDefaultsManager.shared.getUserName() == "Manager"{
            let apiURL = APIList().urlString(url:.managerLogin)+"username=\(userNameOutlet.text ?? "")&password=\(passwordOutlet.text ?? "")"
            print(apiURL)
            APIHandler().getAPIValues(type: ManagerLoginModel.self, apiUrl: apiURL, method: "GET") { [self]  result in
                   switch result {
                   case .success(let data):
                       self.ManagerLoginData = data
                     print(data)
                       if self.ManagerLoginData.status == true{
                           DispatchQueue.main.async {
                               self.stopIndicator()
                               UserDefaultsManager.shared.saveUserId(userNameOutlet.text ?? "")
                               let vc = self.storyboard?.instantiateViewController(withIdentifier: "equipmentViewController") as! equipmentViewController
                               self.navigationController?.pushViewController(vc, animated: true)
                          }
                       }
                       else if self.ManagerLoginData.status == false{
                           DispatchQueue.main.async {
                               self.stopIndicator()
                           print(self.ManagerLoginData.message!)
                           showToast(self.ManagerLoginData.message ?? "Error")
                           }
                       }
                       case .failure(let error):
                       print(error)
                       DispatchQueue.main.async {
                           self.stopIndicator()
                       let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                       alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                           print("JSON Error")
                       })
                       self.present(alert, animated: true, completion: nil)
                       }
                   }
               }
            
        }else if UserDefaultsManager.shared.getUserName() == "User"  {
            
            let apiURL = APIList().urlString(url:.managerLogin)+"username=\(userNameOutlet.text ?? "")&password=\(passwordOutlet.text ?? "")"
            print(apiURL)
            APIHandler().getAPIValues(type: ManagerLoginModel.self, apiUrl: apiURL, method: "GET") { [self]  result in
                   switch result {
                   case .success(let data):
                       self.ManagerLoginData = data
                     print(data)
                       if self.ManagerLoginData.status == true{
                           DispatchQueue.main.async {
                               self.stopIndicator()
                               UserDefaultsManager.shared.saveUserId(userNameOutlet.text ?? "")
                               let vc = self.storyboard?.instantiateViewController(withIdentifier: "issueViewController") as! issueViewController
                               vc.userID = userNameOutlet.text ?? ""
                               self.navigationController?.pushViewController(vc, animated: true)
                          }
                       }
                       else if self.ManagerLoginData.status == false{
                           DispatchQueue.main.async {
                               self.stopIndicator()
                           print(self.ManagerLoginData.message!)
                           showToast(self.ManagerLoginData.message ?? "Error")
                           }
                       }
                       case .failure(let error):
                       print(error)
                       DispatchQueue.main.async {
                           self.stopIndicator()
                       let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                       alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                           print("JSON Error")
                       })
                       self.present(alert, animated: true, completion: nil)
                       }
                   }
               }

            
        }else {
            
            let apiURL = APIList().urlString(url:.managerLogin)+"username=\(userNameOutlet.text ?? "")&password=\(passwordOutlet.text ?? "")"
            print(apiURL)
            APIHandler().getAPIValues(type: ManagerLoginModel.self, apiUrl: apiURL, method: "GET") { [self]  result in
                   switch result {
                   case .success(let data):
                       self.ManagerLoginData = data
                     print(data)
                       if self.ManagerLoginData.status == true{
                           DispatchQueue.main.async {
                               self.stopIndicator()
                               UserDefaultsManager.shared.saveUserId(userNameOutlet.text ?? "")
                               let vc = self.storyboard?.instantiateViewController(withIdentifier: "getIssueViewController") as! getIssueViewController
                               self.navigationController?.pushViewController(vc, animated: true)
                          }
                       }
                       else if self.ManagerLoginData.status == false{
                           DispatchQueue.main.async {
                               self.stopIndicator()
                           print(self.ManagerLoginData.message!)
                           showToast(self.ManagerLoginData.message ?? "Error")
                           }
                       }
                       case .failure(let error):
                       print(error)
                       DispatchQueue.main.async {
                           self.stopIndicator()
                       let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                       alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                           print("JSON Error")
                       })
                       self.present(alert, animated: true, completion: nil)
                       }
                   }
               }

            
        }
        
    }
}
