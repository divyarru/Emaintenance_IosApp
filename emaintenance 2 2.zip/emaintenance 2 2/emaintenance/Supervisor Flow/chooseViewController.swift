//
//  chooseViewController.swift
//  emaintenance
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class chooseViewController: baseViewController, UITextFieldDelegate {
    @IBOutlet weak var WorkerTextfield: UITextField!
    
    @IBOutlet weak var IssueTextfield: UITextField!
    
    @IBOutlet weak var dateTextfield: UITextField!
    
    @IBOutlet weak var EquipmentTextfield: UITextField!
    
    @IBOutlet weak var locationTextfield: UITextField!
  
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var menuButton: UIButton!
    
    
    var getWorkerData: getWorkerModel!
    var getWorkerList: [getWorkerData] = []
    let datePicker : UIDatePicker = UIDatePicker()
    var postAssignData: postaAssignModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getAPI()
        
        WorkerTextfield.delegate = self
        dateTextfield.delegate = self
        dateTextfield.tag = 0
    }
    
    
    @IBAction func backButtonAction(_ sender: UIButton) {
        
      self.navigationController?.popViewController(animated: true)
    
    }
    @IBAction func menuButtonAction(_ sender: UIButton) {
        
        self.present(self.menu!, animated: true, completion: nil)
    
    }
    @IBAction func AssignButton(_ sender: Any) {
        if IssueTextfield.text?.isEmpty == true{
            showToast("Equipment Id Required")
        }else if dateTextfield.text?.isEmpty == true{
            showToast("Equipment Name Required")
        }else if EquipmentTextfield.text?.isEmpty == true{
            showToast("Issue type Required")
        }else if locationTextfield.text?.isEmpty == true{
            showToast("Location Required")
        }else{
            postAPI()
        }
        
    
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == WorkerTextfield {
            textField.resignFirstResponder()
            let alert = UIAlertController(title: "", message: "Select Location", preferredStyle: .actionSheet)
            for place in getWorkerList {
                alert.addAction(UIAlertAction(title: place.name, style: .default, handler: { (action) in
                    self.WorkerTextfield.text = place.name
                }))
            }
            
            alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: { (action) in
                print("Cancelled")
            }))
            
            alert.popoverPresentationController?.sourceView = self.view
            self.present(alert, animated: true, completion: {
                print("completion block")
            })
            return false
        }
        return true
    }
    @IBAction func dateTextFieldBeginEditing(_ sender: UITextField) {
        showDatePicker(tag: sender.tag)
    }
    
    func showDatePicker(tag: Int){
        datePicker.datePickerMode = .date
        
        if #available(iOS 13.4, *) {
            datePicker.preferredDatePickerStyle = .inline
        }
        else {
            datePicker.preferredDatePickerStyle = .wheels
        }
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(self.donedatePicker(_ :)))
        doneButton.tag = tag
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        
        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.cancelDatePicker(_ :)))
        cancelButton.tag = tag
        toolbar.setItems([cancelButton ,spaceButton,doneButton], animated: false)
        self.dateTextfield.inputAccessoryView = toolbar
        self.dateTextfield.inputView = datePicker
    }
    
    @objc func cancelDatePicker(_ sender: UIButton){
        self.dateTextfield.text? = ""
        self.view.endEditing(true)
    }
    
    @objc func donedatePicker(_ sender: UIButton){
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        self.dateTextfield.text = formatter.string(from: datePicker.date)
        self.view.endEditing(true)
    }
}

extension chooseViewController{
    
    func getAPI(){
        self.startIndicator()
        let apiURL = APIList().urlString(url:.getWorkerdata)
        print(apiURL)
           APIHandler().getAPIValues(type: getWorkerModel.self, apiUrl: apiURL, method: "GET") {  result in
               switch result {
               case .success(let data):
                   DispatchQueue.main.async {
                       self.getWorkerList = data.data
                       self.stopIndicator()
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                       self.stopIndicator()
                   let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
    }
        
        
        func postAPI(){
            
            let formData = ["servicetype":"\(IssueTextfield.text ?? "")",
                       "date":"\(dateTextfield.text ?? "")",
                       "equipment":"\(EquipmentTextfield.text ?? "")","name":"\(WorkerTextfield.text ?? "")",
                       "location":"\(locationTextfield.text ?? "")"]
            
            self.startIndicator()
            let apiURL = APIList().urlString(url:.postAssignData)
            print(apiURL)
               APIHandler().postAPIValues(type: postaAssignModel.self, apiUrl: apiURL, method: "POST", formData: formData) {  result in
                   switch result {
                   case .success(let data):
                       self.postAssignData = data
                       DispatchQueue.main.async {
                       self.stopIndicator()
                           self.showToast(self.postAssignData.message)
                           self.showAlert(title: "Details", message: self.postAssignData.message) {
                                   }
                       }
                       case .failure(let error):
                       
                       print(error)
                       DispatchQueue.main.async {
                           self.stopIndicator()
                           self.showToast("failure")
                       let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                       alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                           print("JSON Error")
                       })
                          
                       self.present(alert, animated: true, completion: nil)
                       }
                   }
               }
        }
}
