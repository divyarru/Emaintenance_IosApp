//
//  statusViewController.swift
//  emaintenance
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class statusViewController: baseViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var menuButton: UIButton!
    @IBOutlet weak var segmentControllerOutlet: UISegmentedControl!
    
    var completedData = [workStatus]()
    var pendingData = [workStatus]()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getAPI()
        self.initialLoads()
       
    }
    func initialLoads(){
      
        tableView.delegate = self
        tableView.dataSource = self
        
    }
    override func viewWillAppear(_ animated: Bool) {
        self.getAPI()
    }
    
    
    @IBAction func backButtonAction(_ sender: UIButton) {
        
      self.navigationController?.popViewController(animated: true)
    
    }
    @IBAction func menuButtonAction(_ sender: UIButton) {
        
        self.present(self.menu!, animated: true, completion: nil)
    
    }

    @IBAction func segmentButtonAction(_ sender: Any) {
        switch segmentControllerOutlet.selectedSegmentIndex {
            case 0:
            self.getAPI()
            self.tableView.reloadData()
                
            case 1:
            self.getAPI()
            self.tableView.reloadData()
            default:
                break;
            }
    }
    

}
extension statusViewController{
    
    func getAPI(){
        self.startIndicator()
        let apiURL = APIList().urlString(url:.workstatus)
        print(apiURL)
           APIHandler().getAPIValues(type: workStatusModel.self, apiUrl: apiURL, method: "GET") {  result in
               switch result {
               case .success(let data):
                   let obj = data
                   let Details = obj.data ?? []
                 print(data)
                   if obj.status == true{
                   DispatchQueue.main.async {
                       self.stopIndicator()
                       self.tableView.reloadData()
                   self.completedData = Details.filter{
                       ($0.status == "completed")
                   }
                   self.pendingData = Details.filter{
                       ($0.status == "pending")
                   }
                      }
                       print("completedDAta : \(self.completedData)")
                       print("pemdingDAta : \(self.pendingData)")
                       
                   }
                   else if obj.status == false{
                       DispatchQueue.main.async {
                           self.stopIndicator()
                       self.showToast(obj.message ?? "Error")
                       }
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                       self.stopIndicator()
                   let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                      
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
    }
}


extension statusViewController : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if segmentControllerOutlet.selectedSegmentIndex == 0 {
            return pendingData.count
        }else{
            return completedData.count
        }
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "statusTableViewCell") as! statusTableViewCell

        cell.backgroundColor = UIColor.white
        cell.View.layer.borderColor = UIColor.black.cgColor
        cell.View.layer.borderWidth = 1
        cell.View.layer.cornerRadius = 8
        cell.View.clipsToBounds = true
        
        if segmentControllerOutlet.selectedSegmentIndex == 0 {
            cell.jobIdDetailLabel.text = pendingData[indexPath.row].empid
            cell.dateDetailLabel.text = pendingData[indexPath.row].date
            cell.finishView.isHidden = false
            cell.statusDetailLabel.text = pendingData[indexPath.row].status
            
        }else{
            cell.jobIdDetailLabel.text = completedData[indexPath.row].empid
            cell.dateDetailLabel.text = completedData[indexPath.row].date
            cell.finishView.isHidden = true
            cell.statusDetailLabel.text = completedData[indexPath.row].status
        }
        
        return cell
        
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    
    
    
}
class statusTableViewCell : UITableViewCell{
    
    @IBOutlet weak var View: UIView!
    @IBOutlet weak var jobIdDetailLabel: UILabel!
    @IBOutlet weak var dateDetailLabel: UILabel!
    @IBOutlet weak var statusDetailLabel: UILabel!
    @IBOutlet weak var finishView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    
        finishView.layer.borderColor = UIColor.black.cgColor
        finishView.layer.borderWidth = 1
        finishView.layer.cornerRadius = 8
        finishView.clipsToBounds = true
        
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }


}


