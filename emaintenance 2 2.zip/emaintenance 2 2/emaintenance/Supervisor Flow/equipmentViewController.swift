//
//  equipmentViewController.swift
//  emaintenance
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class equipmentViewController: baseViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
   
    @IBOutlet weak var menuButton: UIButton!
    
    @IBOutlet weak var backButton: UIButton!
    
    @IBOutlet weak var equipmentCollectionView: UICollectionView!
    
    
    
    var equipmentArray = ["AC","FAN","Socket","Generator","Light"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

      
    }
    @IBAction func backButtonAction(_ sender: UIButton) {
        
      self.navigationController?.popViewController(animated: true)
    
    }
    
    @IBAction func menuButtonAction(_ sender: UIButton) {
        
        self.present(self.menu!, animated: true, completion: nil)
    
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        self.equipmentArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "equipmentCell", for: indexPath) as! equipmentCell
        cell.equipmentLabel.text = self.equipmentArray[indexPath.row]
        cell.equipmentView.layer.borderColor = UIColor.black.cgColor
        cell.equipmentView.layer.borderWidth = 1
        cell.equipmentView.layer.cornerRadius = 10
        cell.equipmentView.clipsToBounds = true
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
            
        if indexPath.row == 0{
            UserDefaultsManager.shared.indexKeyName("AC")
        }else if indexPath.row == 1{
            UserDefaultsManager.shared.indexKeyName("FAN")
        }else if indexPath.row == 2{
            UserDefaultsManager.shared.indexKeyName("Socket")
        }else if indexPath.row == 3{
                UserDefaultsManager.shared.indexKeyName("Generator")
        }else if indexPath.row == 4{
            UserDefaultsManager.shared.indexKeyName("Light")
        }
        let ViewController = self.storyboard?.instantiateViewController(withIdentifier: "showEquipmentsViewController") as! showEquipmentsViewController
        ViewController.titleString = UserDefaultsManager.shared.indexKeyName() ?? ""
        self.navigationController?.pushViewController(ViewController, animated: true)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
         let padding: CGFloat =  25
            let collectionViewSize = collectionView.frame.size.width - padding
            return CGSize(width: collectionViewSize/2, height: 150)
        }
}

class equipmentCell : UICollectionViewCell{
    
    @IBOutlet weak var equipmentView: UIView!
    @IBOutlet weak var equipmentLabel: UILabel!
    
}
