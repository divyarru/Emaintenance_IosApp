//
//  StatusUpdateViewController.swift
//  emaintenance
//
//  Created by SAIL on 10/10/23.
//

import UIKit

class StatusUpdateViewController: baseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func nextButtonAction(_ sender: UIButton) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "statusViewController") as! statusViewController
        self.navigationController?.pushViewController(vc, animated: true)
    
    }
    

    
}
