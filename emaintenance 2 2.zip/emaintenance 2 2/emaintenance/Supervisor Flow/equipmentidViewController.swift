//
//  equipmentidViewController.swift
//  emaintenance
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class equipmentidViewController: baseViewController {
    @IBOutlet weak var tableView: UITableView!
        
    @IBOutlet weak var back: UIButton!
        
    @IBOutlet weak var menuButton: UIButton!
    @IBOutlet weak var searchBarOutlet: UISearchBar!
    
    var idData =  UserDefaultsManager.shared.indexKeyName()
    var idModelData : idModel?
    var filteredData : [idData] = []
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        
        getidAPI()
        searchBarOutlet.delegate = self
    }
    
    
    @IBAction func backButtonAction(_ sender: UIButton) {
        
        
    self.navigationController?.popViewController(animated: true)
        
    
    }
    
    @IBAction func menuButtonAction(_ sender: UIButton) {
    
        self.present(self.menu!, animated: true, completion: nil)
    }
}
extension equipmentidViewController{
    
    func getidAPI(){
        self.startIndicator()
        let apiURL = APIList().urlString(url:.idData)
        print(apiURL)
           APIHandler().getAPIValues(type: idModel.self, apiUrl: apiURL, method: "GET") {  result in
               switch result {
               case .success(let data):
                   self.idModelData = data
                 print(data)
                   if self.idModelData?.status == true{
                       
                       DispatchQueue.main.async { [self] in
                           self.stopIndicator()
                           filteredData = idModelData?.data.filter { $0.name == idData } ?? []
                           self.tableView.reloadData()
                      }
                   }
                   else if self.idModelData?.status == false{
                       DispatchQueue.main.async {
                           self.stopIndicator()
                      
                           self.showToast(self.idModelData?.message ?? "" )
                       }
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                       self.stopIndicator()
                   let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
    }
}

extension equipmentidViewController : UISearchBarDelegate{
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
            filteredData = idModelData?.data.filter { idData in
                // Assuming you want to search based on the 'eid' property.
                return idData.eid.lowercased().contains(searchText.lowercased())
            } ?? []
            
            tableView.reloadData()
        }
        func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
            searchBar.text = ""
            filteredData = idModelData?.data ?? []
            tableView.reloadData()
        }
   
}

extension equipmentidViewController : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredData.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "equipmentIdTableViewCell") as! equipmentIdTableViewCell
        cell.backgroundColor = UIColor.white
        cell.View.layer.borderColor = UIColor.black.cgColor
        cell.View.layer.borderWidth = 1
        cell.View.layer.cornerRadius = 8
        cell.View.clipsToBounds = true
        cell.Label.text = filteredData[indexPath.row].eid
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let ViewController = self.storyboard?.instantiateViewController(withIdentifier: "equdetailsViewController") as! equdetailsViewController
        ViewController.idDetailsData = filteredData[indexPath.row].eid
        
        self.navigationController?.pushViewController(ViewController, animated: true)
    }
    
}

class equipmentIdTableViewCell : UITableViewCell{
    
    @IBOutlet weak var View: UIView!
    @IBOutlet weak var Label: UILabel!
    
}
