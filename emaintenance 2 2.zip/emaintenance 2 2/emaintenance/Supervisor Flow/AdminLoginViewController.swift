//
//  AdminLoginViewController.swift
//  emaintenance
//
//  Created by SAIL on 09/10/23.
//

import UIKit

class AdminLoginViewController: baseViewController {
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func superVisorLogin(_ sender: UIButton) {

        UserDefaultsManager.shared.saveUserName("SuperVisor")
        let loginViewController = self.storyboard?.instantiateViewController(withIdentifier: "loginViewController") as! loginViewController
        self.navigationController?.pushViewController(loginViewController, animated: true)
        
    }
    @IBAction func managerVisorLogin(_ sender: UIButton) {
        UserDefaultsManager.shared.saveUserName("Manager")
        let loginViewController = self.storyboard?.instantiateViewController(withIdentifier: "loginViewController") as! loginViewController
        self.navigationController?.pushViewController(loginViewController, animated: true)
        
    }
    @IBAction func userLogin(_ sender: UIButton) {
        UserDefaultsManager.shared.saveUserName("User")
        let loginViewController = self.storyboard?.instantiateViewController(withIdentifier: "loginViewController") as! loginViewController
        self.navigationController?.pushViewController(loginViewController, animated: true)
        
    }
    @IBAction func workersLogin(_ sender: UIButton) {
        UserDefaultsManager.shared.saveUserName("Worker")
        let loginViewController = self.storyboard?.instantiateViewController(withIdentifier: "loginViewController") as! loginViewController
        self.navigationController?.pushViewController(loginViewController, animated: true)
        
    }
    
}


