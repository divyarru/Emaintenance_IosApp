//
//  employeDetailsViewController.swift
//  emaintenance
//
//  Created by SAIL on 14/12/23.
//

//
//  chooseViewController.swift
//  emaintenance
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class employeDetailsViewController: baseViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var menuButton: UIButton!
    @IBOutlet weak var searchBarOutlet: UISearchBar!
    
    var employeDetailsData: employeDetailsModel!
    var filteredData: [employeDetailsData?] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getDetailsAPI()
        self.initialLoads()
    }
    func initialLoads(){
        
        searchBarOutlet.delegate = self
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    @IBAction func backButtonAction(_ sender: UIButton) {
        
      self.navigationController?.popViewController(animated: true)
    
    }
    @IBAction func menuButtonAction(_ sender: UIButton) {
        
        self.present(self.menu!, animated: true, completion: nil)
    
    }
}
extension employeDetailsViewController: UISearchBarDelegate {

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
               if searchText.isEmpty {
                   filteredData = employeDetailsData.data
               } else {
                   filteredData = employeDetailsData.data.filter { ($0.name.lowercased().contains(searchText.lowercased()) ) }
               }
               tableView.reloadData()
           }

    }
extension employeDetailsViewController{
    
    func getDetailsAPI(){
        self.startIndicator()
        let apiURL = APIList().urlString(url:.employeDetailsData)
        print(apiURL)
        print(apiURL)
           APIHandler().getAPIValues(type: employeDetailsModel.self, apiUrl: apiURL, method: "GET") {  result in
               switch result {
               case .success(let data):
                   self.employeDetailsData = data
                 print(data)
                   if self.employeDetailsData.status == true{
                       
                       DispatchQueue.main.async { [self] in
                           self.stopIndicator()
                           filteredData = employeDetailsData?.data ?? []
                           self.tableView.reloadData()
                      }
                   }
                   else if self.employeDetailsData.status == false{
                       DispatchQueue.main.async {
                           self.stopIndicator()
                      
                           self.showToast(self.employeDetailsData.message )
                       }
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                       self.stopIndicator()
                   let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
    }
}

extension employeDetailsViewController : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredData.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "employeDetailsTableViewCell") as! employeDetailsTableViewCell
                    cell.backgroundColor = UIColor.white
                    cell.View.layer.borderColor = UIColor.black.cgColor
                    cell.View.layer.borderWidth = 1
                    cell.View.layer.cornerRadius = 8
                    cell.View.clipsToBounds = true
                    
        cell.nameDetailLabel?.text = filteredData[indexPath.row]?.name
        cell.mobnumDetailLabel?.text = filteredData[indexPath.row]?.mobnum
        cell.roleDetailLabel?.text = filteredData[indexPath.row]?.role
                    
                    return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
        
    }
    
    

class employeDetailsTableViewCell : UITableViewCell{
    
    @IBOutlet weak var View: UIView!
    @IBOutlet weak var nameDetailLabel: UILabel!
    @IBOutlet weak var mobnumDetailLabel: UILabel!
    @IBOutlet weak var roleDetailLabel: UILabel!
}






