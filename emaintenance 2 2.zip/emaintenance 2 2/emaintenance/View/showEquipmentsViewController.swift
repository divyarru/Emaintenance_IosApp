//
//  showEquipmentsViewController.swift
//  emaintenance
//
//  Created by SAIL on 14/12/23.
//

//
//  employeDetailsViewController.swift
//  emaintenance
//
//  Created by SAIL on 14/12/23.
//

//
//  chooseViewController.swift
//  emaintenance
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class showEquipmentsViewController: baseViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var menuButton: UIButton!
    @IBOutlet weak var searchBarOutlet: UISearchBar!
    
    var showEquipmentData: showEquipmentModel!
    var filteredData: [showEquipmentData?] = []
    var titleString = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getShowAPI()
        self.initialLoads()
    }
    func initialLoads(){
        print(titleString)
        searchBarOutlet.delegate = self
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    @IBAction func backButtonAction(_ sender: UIButton) {
        
      self.navigationController?.popViewController(animated: true)
    
    }
    @IBAction func menuButtonAction(_ sender: UIButton) {
        
        self.present(self.menu!, animated: true, completion: nil)
    
    }
}
extension showEquipmentsViewController: UISearchBarDelegate {

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        DispatchQueue.main.async { [self] in
               if searchText.isEmpty {
                   filteredData = showEquipmentData.data
               } else {
                   filteredData = showEquipmentData.data.filter { ($0.eidd.lowercased().contains(searchText.lowercased()) ) }
               }
               tableView.reloadData()
           }
    }
    }
extension showEquipmentsViewController{
    
    func getShowAPI(){
        self.startIndicator()
        let apiURL = APIList().urlString(url:.showEquipmentData)
        print(apiURL)
        print(apiURL)
           APIHandler().getAPIValues(type: showEquipmentModel.self, apiUrl: apiURL, method: "GET") {  result in
               switch result {
               case .success(let data):
                   DispatchQueue.main.async { [self] in
                   self.showEquipmentData = data
                 print(data)
                   if self.showEquipmentData.status == true{
                           self.stopIndicator()
                       filteredData = showEquipmentData.data.filter { ($0.equipment.lowercased() ).contains(titleString.lowercased()) }
                           self.tableView.reloadData()
                   }
                   else if self.showEquipmentData.status == false{
                           self.stopIndicator()
                           self.showToast(self.showEquipmentData.message )
                       }
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                       self.stopIndicator()
                   let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
    }
}

extension showEquipmentsViewController : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredData.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "showEquipmentTableViewCell") as! showEquipmentTableViewCell
           cell.backgroundColor = UIColor.white
           cell.View.layer.borderColor = UIColor.black.cgColor
           cell.View.layer.borderWidth = 1
           cell.View.layer.cornerRadius = 8
           cell.View.clipsToBounds = true
           cell.eiddLabel?.text = filteredData[indexPath.row]?.eidd
           cell.buildingLabel?.text = filteredData[indexPath.row]?.building
           cell.RoomLabel?.text = filteredData[indexPath.row]?.room
                    
      return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let ViewController = self.storyboard?.instantiateViewController(withIdentifier: "equdetailsViewController") as! equdetailsViewController
        ViewController.idDetailsData = filteredData[indexPath.row]?.eidd ?? ""
        
        self.navigationController?.pushViewController(ViewController, animated: true)
    }
    
}


class showEquipmentTableViewCell : UITableViewCell{
    
    @IBOutlet weak var View: UIView!
    @IBOutlet weak var eiddLabel: UILabel!
    @IBOutlet weak var buildingLabel: UILabel!
    @IBOutlet weak var RoomLabel: UILabel!
}

