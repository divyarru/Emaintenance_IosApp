//
//  UserIssueDataViewController.swift
//  emaintenance
//
//  Created by SAIL on 21/12/23.
//

import UIKit

class UserIssueDataViewController: baseViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var menuButton: UIButton!
    @IBOutlet weak var searchBarOutlet: UISearchBar!
    
    var getIssueData: GetUserIssueModel!
    var filteredData: [GetUserIssueData?] = []
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getShowAPI()
        self.initialLoads()
    }
    func initialLoads(){
        searchBarOutlet.delegate = self
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    @IBAction func backButtonAction(_ sender: UIButton) {
        
      self.navigationController?.popViewController(animated: true)
    
    }
    @IBAction func menuButtonAction(_ sender: UIButton) {
        
        self.present(self.menu!, animated: true, completion: nil)
    
    }


}
extension UserIssueDataViewController: UISearchBarDelegate {

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
               if searchText.isEmpty {
                  
                   filteredData = getIssueData.data
                  
               } else {
                   filteredData = getIssueData.data.filter { ($0.eqname.lowercased().contains(searchText.lowercased()) ) }
               }
               tableView.reloadData()
           }

    }
extension UserIssueDataViewController{
    
    func getShowAPI(){
        self.startIndicator()
       
        let apiURL = APIList().urlString(url:.getIssueData)
        print(apiURL)
           APIHandler().getAPIValues(type: GetUserIssueModel.self, apiUrl: apiURL, method: "GET") {  result in
               switch result {
               case .success(let data):
                   DispatchQueue.main.async { [self] in
                   self.getIssueData = data
                 print(data)
                     self.stopIndicator()
                     filteredData = getIssueData?.data ?? []
                     print("Filtered Data: \(filteredData)")
                     self.tableView.reloadData()
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                       self.stopIndicator()
                   let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
    }
}

extension UserIssueDataViewController : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        return filteredData.count
       
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "UserIssueDataTableViewCell") as! UserIssueDataTableViewCell
        
            cell.backgroundColor = UIColor.white
            cell.View.layer.borderColor = UIColor.black.cgColor
            cell.View.layer.borderWidth = 1
            cell.View.layer.cornerRadius = 8
            cell.View.clipsToBounds = true
                    
            cell.equipmentIssueLabel?.text = filteredData[indexPath.row]?.eqname
            cell.IssueLabel?.text = filteredData[indexPath.row]?.issue
            cell.LocationLabel?.text = filteredData[indexPath.row]?.location
            cell.DateLabel?.text = filteredData[indexPath.row]?.date
    
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
       
}
class UserIssueDataTableViewCell : UITableViewCell{
    
    @IBOutlet weak var View: UIView!
    @IBOutlet weak var equipmentIssueLabel: UILabel!
    @IBOutlet weak var IssueLabel: UILabel!
    @IBOutlet weak var LocationLabel: UILabel!
    @IBOutlet weak var DateLabel: UILabel!
}
