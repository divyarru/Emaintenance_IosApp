//
//  getIssueViewController.swift
//  emaintenance
//
//  Created by SAIL on 15/12/23.
//

import UIKit

class getIssueViewController: baseViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var menuButton: UIButton!
    @IBOutlet weak var searchBarOutlet: UISearchBar!
    
    var getIssueData: getIssueModel!
    var filteredData: [getIssueData?] = []
    var closeIssueData: closeIssueModel!
    var WorkerIssueData: WorkerIssueModel!
    var filteredWorkerData: [WorkerIssueData?] = []
    var WorkerButtonIssueData: WorkerButtonModel!
    var conditionFlowCheck = UserDefaultsManager.shared.getUserName()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getShowAPI()
        self.initialLoads()
    }
    func initialLoads(){
        searchBarOutlet.delegate = self
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    @IBAction func backButtonAction(_ sender: UIButton) {
        
      self.navigationController?.popViewController(animated: true)
    
    }
    @IBAction func menuButtonAction(_ sender: UIButton) {
        
        self.present(self.menu!, animated: true, completion: nil)
    
    }
    @objc func closeButtonAct(_ sender: UIButton) {
        let tag = sender.tag
        if conditionFlowCheck == "User"  {
        guard tag < filteredData.count, let idName = filteredData[tag]?.iid else {
            print("Error: Unable to get valid index or iid")
            return
        }

        postAPI(id: idName)
        }else{
            guard tag < filteredWorkerData.count, let idName = filteredWorkerData[tag]?.jid else {
                print("Error: Unable to get valid index or iid")
                return
            }

            postAPI(id: idName)
        }
    }

}
extension getIssueViewController: UISearchBarDelegate {

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
               if searchText.isEmpty {
                   if conditionFlowCheck == "User"  {
                   filteredData = getIssueData.data
                   }else{
                       filteredWorkerData = WorkerIssueData.data
                   }
               } else {
                   if conditionFlowCheck == "User"  {
                   filteredData = getIssueData.data.filter { ($0.eqname.lowercased().contains(searchText.lowercased()) ) }
                   }else{
                       filteredWorkerData = WorkerIssueData.data.filter { ($0.equipment.lowercased().contains(searchText.lowercased()) ) }
                   }
               }
               tableView.reloadData()
           }

    }
extension getIssueViewController{
    
    func getShowAPI(){
        self.startIndicator()
        if conditionFlowCheck == "User"  {
        let apiURL = APIList().urlString(url:.getIssueData)
        print(apiURL)
           APIHandler().getAPIValues(type: getIssueModel.self, apiUrl: apiURL, method: "GET") {  result in
               switch result {
               case .success(let data):
                   DispatchQueue.main.async { [self] in
                   self.getIssueData = data
                 print(data)
                  
                     self.stopIndicator()
                     filteredData = getIssueData?.data ?? []
                     print("Filtered Data: \(filteredData)")
                     self.tableView.reloadData()
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                       self.stopIndicator()
                   let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
        } else {
            let apiURL = APIList().urlString(url:.WorkerIssue)
            print(apiURL)
               APIHandler().getAPIValues(type: WorkerIssueModel.self, apiUrl: apiURL, method: "GET") {  result in
                   switch result {
                   case .success(let data):
                       DispatchQueue.main.async { [self] in
                       self.WorkerIssueData = data
                     print(data)
                      
                         self.stopIndicator()
                           filteredWorkerData = WorkerIssueData?.data ?? []
                         print("filteredWorker Data: \(filteredWorkerData)")
                         self.tableView.reloadData()
                       }
                       case .failure(let error):
                       print(error)
                       DispatchQueue.main.async {
                           self.stopIndicator()
                       let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                       alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                           print("JSON Error")
                       })
                       self.present(alert, animated: true, completion: nil)
                       }
                   }
               }
        }
    }
   
    func postAPI(id: String){
        
        
        self.startIndicator()
        if conditionFlowCheck == "User"  {
        let apiURL = APIList().urlString(url:.closeIssue) + "iid=\(id)"
        print(apiURL)
        APIHandler().postAPIValues(type: closeIssueModel.self, apiUrl: apiURL, method: "POST", formData: [:]) {  result in
               switch result {
               case .success(let data):
                   self.closeIssueData = data
                   DispatchQueue.main.async {
                   self.stopIndicator()
                       self.showToast(self.closeIssueData.message)
                       
                       self.showAlert(title: "Details", message: self.closeIssueData.message) {
                           self.getShowAPI()
                           self.tableView.reloadData()
                               }
                   }
                 print(data)
                case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {
                       self.stopIndicator()
                       self.showToast("failure")
                   let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                      
                   self.present(alert, animated: true, completion: nil)
                   }
               }
           }
        }else{
            let apiURL = APIList().urlString(url:.WorkerCloseIssue) + "jid=\(id)"
            print(apiURL)
            APIHandler().postAPIValues(type: WorkerButtonModel.self, apiUrl: apiURL, method: "POST", formData: [:]) {  result in
                   switch result {
                   case .success(let data):
                       self.WorkerButtonIssueData = data
                       DispatchQueue.main.async {
                       self.stopIndicator()
                           self.showToast(self.WorkerButtonIssueData.message)
                           self.showAlert(title: "Details", message: self.WorkerButtonIssueData.message) {
                               self.getShowAPI()
                               self.tableView.reloadData()
                                   }
                       }
                     print(data)
                    case .failure(let error):
                       print(error)
                       DispatchQueue.main.async {
                           self.stopIndicator()
                           self.showToast("failure")
                       let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                       alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                           print("JSON Error")
                       })
                       self.present(alert, animated: true, completion: nil)
                       }
                   }
               }
        }
    }
}

extension getIssueViewController : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if conditionFlowCheck == "User"  {
        return filteredData.count
        }else{
        return filteredWorkerData.count
      }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "getIssueTableViewCell") as! getIssueTableViewCell
        
                    cell.backgroundColor = UIColor.white
                    cell.View.layer.borderColor = UIColor.black.cgColor
                    cell.View.layer.borderWidth = 1
                    cell.View.layer.cornerRadius = 8
                    cell.View.clipsToBounds = true
                    
        if conditionFlowCheck == "User"  {
        
            cell.equipmentIssueLabel?.text = filteredData[indexPath.row]?.eqname
            cell.IssueLabel?.text = filteredData[indexPath.row]?.issue
            cell.LocationLabel?.text = filteredData[indexPath.row]?.location
            cell.DateLabel?.text = filteredData[indexPath.row]?.date
            cell.closeIssueButton.tag = indexPath.row
            cell.closeIssueButton.addTarget(self, action: #selector(closeButtonAct(_:)), for: .touchUpInside)
        }else{
            
            cell.equipmentIssueLabel?.text = filteredWorkerData[indexPath.row]?.equipment
            cell.IssueLabel?.text = filteredWorkerData[indexPath.row]?.servicetype
            cell.LocationLabel?.text = filteredWorkerData[indexPath.row]?.location
            cell.DateLabel?.text = filteredWorkerData[indexPath.row]?.date
            cell.closeIssueButton.tag = indexPath.row
            cell.closeIssueButton.addTarget(self, action: #selector(closeButtonAct(_:)), for: .touchUpInside)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
       
}
    
class getIssueTableViewCell : UITableViewCell{
    
    @IBOutlet weak var View: UIView!
    @IBOutlet weak var equipmentIssueLabel: UILabel!
    @IBOutlet weak var IssueLabel: UILabel!
    @IBOutlet weak var LocationLabel: UILabel!
    @IBOutlet weak var DateLabel: UILabel!
    @IBOutlet weak var closeIssueButton: UIButton!
}
